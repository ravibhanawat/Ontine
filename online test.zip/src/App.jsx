import React,{ useState } from 'react';
import './App.css';
import {isEmpty} from "lodash"
import QuizPage from './Components/QuizPage';
import ResisterPage from './Components/ResisterPage';
import ResultPage from './Components/ResultPage';
import {ExamContexts} from "./ContextApicall/Contexts"
import QuestionSendtoDatabase from './Questions/QuestionSendtoDatabase';
function App() {
  // const setValue = localStorage.setItem("value", "resisterPage")
  const getValue = localStorage.getItem("value")
  const [QuizApp,setQuizApp]= useState(!isEmpty(getValue) ? getValue : "resisterPage")

  
  const [finalScore,setFinalScore]= useState(0)
  return (
    <>
     <h1 className='App'>ONLINE EXAM QUIZ</h1>
    <div>
     
     <ExamContexts.Provider value={{QuizApp, setQuizApp,finalScore,setFinalScore}}>
     {QuizApp === "resisterPage" && <ResisterPage />}
     {QuizApp === "QuestionPage" && <QuestionSendtoDatabase />}
     {QuizApp === "QuizPage" && <QuizPage />}
     {QuizApp === "ResultPage" && <ResultPage />}
     </ExamContexts.Provider>
    </div>
    </>
  );
}

export default App;
