import { db } from "../../Questions/FireBase_config";
import { collection,getDocs,getDoc,addDoc,updateDoc,deleteDoc,doc } from "firebase/firestore";

const studentsRef = collection(db,"student")
class StudentAdd {
    AddStududentsData =(newstudent)=>{
        return addDoc(studentsRef,newstudent)
    }
    updateStudent=(id,updatestudent)=>{
        const studentAvail = doc(db,"student",id)
        return updateDoc(studentAvail,updatestudent)
    }
    deleteStudent =(id)=>{
        const studentAvail = doc(db,"student",id)
        return deleteDoc(studentAvail)

    }
    getAllStudent =()=>{
        return getDocs(studentsRef)
    }
    getSingleStudent =(id)=>{
        const studentsingle = doc(db,"student",id)

        return getDoc(studentsingle)
    }
}
export default new StudentAdd();