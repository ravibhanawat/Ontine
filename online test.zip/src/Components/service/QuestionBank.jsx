import { db } from "../../Questions/FireBase_config";
import { collection,getDocs,getDoc,addDoc,updateDoc,deleteDoc,doc } from "firebase/firestore";

const QuestionRef = collection(db,"QuestionBank")
class QuestionAdd {
    AddQuestionData =(newstudent)=>{
        return addDoc(QuestionRef,newstudent)
    }
    updateQuestion=(id,updatestudent)=>{
        const studentAvail = doc(db,"QuestionBank",id)
        return updateDoc(studentAvail,updatestudent)
    }
    deleteQuestion =(id)=>{
        const studentAvail = doc(db,"QuestionBank",id)
        return deleteDoc(studentAvail)

    }
    getAllQuestion =()=>{
        return getDocs(QuestionRef)
    }
    getSingleQuestion =(id)=>{
        const studentsingle = doc(db,"QuestionBank",id)

        return getDoc(studentsingle)
    }
}
export default new QuestionAdd();