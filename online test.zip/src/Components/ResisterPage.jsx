import { Button,Row,Col, Upload, Form, Input,Select } from 'antd'
import "../App.css"
import logo from "../asset/sideimage/sidebar.jpg"
import React,{useContext, useEffect} from 'react'
import StudentAdd from "../Components/service/Quesfire"
import { ExamContexts } from '../ContextApicall/Contexts'
const {Option} =Select
const ResisterPage = () => {
  const {QuizApp, setQuizApp} = useContext(ExamContexts)
  const [form] = Form.useForm();
  
  
  const OnFinish =(value)=>{
      localStorage.removeItem("value")
      localStorage.setItem("value","QuestionPage")
      localStorage.setItem("Quiz", JSON.stringify(value))
      const getvalue = localStorage.getItem("value")
      setQuizApp(getvalue)
      try{
      StudentAdd.AddStududentsData(value)
      form.resetFields()
    }catch (err){
      console.log("err",err)
      form.resetFields()

    }
  }
    const widthS = window.innerWidth/2
  return (
      <>
    {/* <div className='resister'> */}
    
    <Row>
      <Col span={12}>
        <img src={logo} height={680} width={`${widthS}px`} />
        </Col>
        <Col span={12}>
          <h1 style={{display: 'flex',padding: "0px 150px",justifyContent:"center",color:"purple"}}>Resistration Form</h1>
          <Form
          style={{margin: "50px 10px",padding: "0px 50px"}}
          form={form}
          layout="vertical"
          l
          onFinish={OnFinish}
          >
            <Form.Item
             label="Name"
             name="name"
             rules={[{ required: true, message: 'Please input your Name!' }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
             label="Email"
             name="email"
             rules={[{ required: true, message: 'Please input your Email!' }]}
            >
              <Input type={"email"} />
            </Form.Item>
            <Form.Item
             label="Qualification"
             name="qualification"
             rules={[{ required: true, message: 'Please input your Qualification!' }]}
            >
              <Select placeholder="Select your Qualification">
          <Option value="hsc">Hsc</Option>
          <Option value="graduation">Graduation</Option>
          <Option value="post_graduation">Post Graduation</Option>
        </Select>
            </Form.Item>
            <Form.Item
             label="State"
             name="state"
             rules={[{ required: true, message: 'Please input your State!' }]}
            >
              <Input  />
            </Form.Item>
            <Form.Item
             label="Gender"
             name="gender"
             rules={[{ required: true, message: 'Please select gender!' }]}
            >
              <Select placeholder="select your gender">
          <Option value="male">Male</Option>
          <Option value="female">Female</Option>
          <Option value="other">Other</Option>
        </Select>
            </Form.Item>
            <Form.Item
             style={{textAlign: "center"}}
            >
              
          <Button htmlType='submit' type='primary' >Start Quiz</Button>
            </Form.Item>

          </Form>
        </Col>
    </Row>

    {/* </div> */}
    </>
  )
}

export default ResisterPage