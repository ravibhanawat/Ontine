import { Button, Card, List, Radio, Space } from 'antd'
import { Statistic, Row, Col } from 'antd';
import React,{useState,useContext, useEffect, useReducer} from 'react'
import "../App.css"
import { initialState,reducers } from '../ContextApicall/Reducers';
import QuestionAdd from "../Components/service/QuestionBank"

import { ExamContexts } from '../ContextApicall/Contexts'
// import {Questions} from "../Questions/QuestionAns"
import { isEmpty } from '@firebase/util';
const { Countdown } = Statistic;
const QuizPage = () => {
  const [state,dispatch] = useReducer(reducers,initialState)  
  const deadline = Date.now() + 1000 * 60 * 15

    const {finalScore,setFinalScore,QuizApp, setQuizApp} = useContext(ExamContexts)
   const [currentQuestion,setCurrQuestion] = useState(0) 
   const [currentQues,setQuestion] = useState([]) 
   const [val,setVal] = useState(false)
   const [optionChoose,setOptionChoose] =useState("")
  useEffect(()=>{
    getData()
  },[])

  const getData =async() =>{
    try{
      const data = await QuestionAdd.getAllQuestion()
    
    setQuestion(data.docs.map((doc)=>({...doc.data(),id: doc.id})))
    dispatch({type: "val",payload:data.docs.map((doc)=>({...doc.data(),id: doc.id}))})
    }
    catch (err){

    }
  }
  let UserUnfo = localStorage.getItem("Quiz")
   UserUnfo =   !isEmpty(UserUnfo) && JSON.parse(UserUnfo)

  const NextQuestion =()=>{
    if (currentQues[currentQuestion].Answer == optionChoose){
        setFinalScore(finalScore + 1);
    }
    setCurrQuestion(currentQuestion +1);
    setVal(null)
  } 

  
  
  
const FinishQuiz =()=>{
    if (currentQues[currentQuestion].Answer == optionChoose){
        setFinalScore(finalScore + 1);
    }
    localStorage.removeItem("value")
    localStorage.setItem("value","ResultPage")
    const getval = localStorage.getItem("value")
    setQuizApp(getval)
}
const onChange =(e)=>{
    console.log(e)
    setOptionChoose(e.target.value)
    setVal(e.target.value)
    dispatch({type: "value",payload: {value:  e.target.value,name: e.target.name}})
}
const hieght = window.innerHeight
console.log("cu",currentQues)
  return (
      <>
    <div >
      <Row>
        <Col  span={12}>
          <List 
          dataSource={!isEmpty(currentQues)? currentQues : []}
          >
          <Card
          title={<p style={{fontSize: 14}}>{currentQues[currentQuestion]?.Quiz}</p>}
          style={{textAlign: "center",backgroundColor: "deepskyblue",height: hieght,}}
          >
        
        <div style={{margin: 10,}}>
          
          <Radio.Group name={currentQues[currentQuestion]?.Quiz} value={val} onChange={onChange} defaultValue={null} buttonStyle="solid">
            <Space size={30} direction='vertical'>
            <Radio type='primary' value={"A"} >{currentQues[currentQuestion]?.OptionA}</Radio>
            <Radio value={"B"} >{currentQues[currentQuestion]?.OptionB}</Radio>
            <Radio value={"C"} >{currentQues[currentQuestion]?.OptionC}</Radio>
            <Radio value={"D"}>{currentQues[currentQuestion]?.OptionD}</Radio>
            </Space>
            {/* <Radio.Button onClick={()=>setOptionChoose("D")}>{currentQues[currentQuestion].OptionD}</Radio.Button> */}
          </Radio.Group>
          </div>
          <div style={{margin: "10px 10px",padding: "100</Space>px 0px",background: "green"}} >
          <Space size={30}>
        {currentQuestion == currentQues.length -1 ?
        
        <Button onClick={FinishQuiz}>Finish Quiz</Button>
        :<Button onClick={NextQuestion}>Next Question</Button>
    }
    </Space>
    </div>
        </Card>
       
          </List>
          
        </Col>
        <Col span={12}>
          <div style={{padding: "70px 0px",border: "2px solid red",textAlign: "center"}}>
      <Countdown title="Countdown" value={deadline}  onFinish={FinishQuiz} />
      </div>
          <div style={{padding: "70px 0px",margin: 10, border: "2px solid red",textAlign: "center"}}>
      <div>
      <p>{UserUnfo.name}</p>
      <p>{UserUnfo.email}</p>
      <p>{UserUnfo.gender}</p>
      <p>{UserUnfo.state}</p>

      </div>
      </div>
        </Col>
      </Row>
        
    {/* <Col span={12}>
    </Col> */}
        </div>
        </>
  )
}

export default QuizPage