import React,{useContext,useReducer} from 'react'
// import { Questions } from '../Questions/QuestionAns'
import { SmileOutlined,FrownTwoTone } from '@ant-design/icons';
import { ExamContexts } from '../ContextApicall/Contexts'
import { initialState,reducers } from '../ContextApicall/Reducers';
import "../App.css"
import { Button, Result } from 'antd'
import { isEmpty } from 'lodash';
const ResultPage = () => {
    const {finalScore,setFinalScore,setQuizApp,currentQues} = useContext(ExamContexts)
  const [state,dispatch] = useReducer(reducers,initialState)  
    
    
     const finalResults =  ((finalScore >=0 || finalScore <= 5) ? "Fair": (finalScore >=6 || finalScore <= 10) ? "Good": (finalScore >=11 || finalScore <= 15) ?"Excellent": null )
     

    const finishQuiz =()=>{
        setFinalScore(0)
        localStorage.removeItem("value")
        localStorage.removeItem("Quiz")
        // localStorage.setItem("value","registerPage")
        // const getItem = localStorage.getItem("value")

        setQuizApp("registerPage")
        window?.reload()
    }
    console.log("state",state)
  return (
    <div className='result'>
        <h1>Quiz Finished</h1>
        {
          <Result
          icon={finalResults =="Excellent" || "Good" ?  <SmileOutlined />: <FrownTwoTone />}
    title={finalResults}
        
        subTitle={<h3>{finalScore}/ {(state?.length) ? state?.length : 15 }</h3> }
    extra={[
     
        <Button onClick={finishQuiz}>Finish</Button>

      
    ]}
          />
            
        }
        </div>
  )
}

export default ResultPage