export const initialState = {
    dataSource: [],

};

export const reducers =(state=initialState,action)=>{
    // console.log("state",state,action)
    switch (action.type) {
        case "val":
        return {
            ...state,
            dataSource: action.payload
        }
            
            break;
    
        default:
            return state
            
    }

}