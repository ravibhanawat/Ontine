import { createContext } from "react";

export const ExamContexts = createContext()