import { Button, Row, Col, Upload, Form, Input, Select } from "antd";
import "../App.css";
import logo from "../asset/sideimage/sidebar.jpg";
import React, { useContext, useEffect } from "react";
import QuestionAdd from "../Components/service/QuestionBank";
import { ExamContexts } from "../ContextApicall/Contexts";
const { Option } = Select;

const QuestionSendtoDatabase = () => {
   
  const { QuizApp, setQuizApp } = useContext(ExamContexts);
  const [form] = Form.useForm();

  const OnFinish = async (value) => {
    try {
      await QuestionAdd.AddQuestionData(value);
      form.resetFields();
    } catch (err) {
      console.log("err", err);
      form.resetFields();
    }
  };

  const onClick = () => {
    localStorage.removeItem("value")
    localStorage.setItem("value","QuizPage")

      const getval =localStorage.getItem("value" )
      setQuizApp(getval)
    
  };
  const widthS = window.innerWidth / 2;
  return (
    <>
      {/* <div className='resister'> */}

      <Row>
        <Col span={12}>
          <img src={logo} height={680} width={`${widthS}px`} />
        </Col>
        <Col span={12}>
          <h1
            style={{
              display: "flex",
              padding: "0px 150px",
              justifyContent: "center",
              color: "purple",
            }}
          >
            Question Form
          </h1>
          <p style={{ margin: "10px 50px" }}>
            <h1>Rules to follow during all online proctored exams:</h1>
            <b>You must use a functioning webcam and microphone</b>
            <b>
              No cell phones or other secondary devices in the room or test area
            </b>
            <b>
              Your desk/table must be clear or any materials except your
              test-taking device
            </b>
            <i> No one else can be in the room with you. </i>
            <b>
              No talking The testing room must be well-lit and you must be
              clearly visible
            </b>
            <b>No dual screens/monitors</b>
            <b>Do not leave the camera</b>
            <b>No use of additional applications or internet</b>
          </p>
          {/* <Form
            style={{margin: "50px 10px",padding: "0px 50px"}}
            form={form}
            layout="vertical"
            l
            onFinish={OnFinish}
            >
                
              
              <Form.Item
               label="Question"
               name="Quiz"
               rules={[{ required: true, message: 'Please input your Question!' }]}
              >
                <Input />
              </Form.Item>
              <Form.Item
               label="Option A"
               name="OptionA"
               rules={[{ required: true, message: 'Please input Option A!' }]}
              >
                <Input  />
              </Form.Item>
              <Form.Item
               label="Option B"
               name="OptionB"
               rules={[{ required: true, message: 'Please input Option B' }]}
              >
               <Input />
              </Form.Item>
              <Form.Item
               label="Option C"
               name="OptionC"
               rules={[{ required: true, message: 'Please input Option C!' }]}
              >
                <Input  />
              </Form.Item>
              <Form.Item
               label="Option D"
               name="OptionD"
               rules={[{ required: true, message: 'Please select gender!' }]}
              >
               <Input />
              </Form.Item>
              <Form.Item
               label="Answer"
               name="Answer"
               rules={[{ required: true, message: 'Please select Answer!' }]}
              >
                <Select placeholder="Select your Answer">
            <Option value="A">A</Option>
            <Option value="B">B</Option>
            <Option value="C">C</Option>
            <Option value="D">D</Option>
          </Select>
              </Form.Item>
              <Form.Item
               style={{textAlign: "center"}}
              >
                
            <Button htmlType='submit' type='primary' > Post</Button>
              </Form.Item>
  
            </Form> */}
          <Button style={{textAlign: "center",justifyContent: "center",display: "flex",alignItems: "center",padding: "0px 70px",margin: "120px 160px"}} onClick={onClick}>Start Exam</Button>
        </Col>
      </Row>

      {/* </div> */}
    </>
  );
};

export default QuestionSendtoDatabase;
