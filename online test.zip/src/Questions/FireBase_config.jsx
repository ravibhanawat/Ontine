// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore"
const firebaseConfig = {
  apiKey: "AIzaSyDoLQFfADtRua34A1Sp8NuAqkWcLkLpyQU",
  authDomain: "examonline-f55fc.firebaseapp.com",
  projectId: "examonline-f55fc",
  storageBucket: "examonline-f55fc.appspot.com",
  messagingSenderId: "463529932996",
  appId: "1:463529932996:web:3c7e76677d44ed7edaf191",
  measurementId: "G-QGJ04VS5M3"
};


const app = initializeApp(firebaseConfig);

export const db = getFirestore(app)