// interface Questionsexam {
//     Quiz: string;
//     OptionA: string;
//     OptionB: string;
//     OptionC: string;
//     OptionD: string;
//     Answer: string;

// }
export const Questions = [
    {
     Quiz: "Who is Prime Misiter Of India?",
     OptionA: "Rahul Gandhi",   
     OptionB: "Narendra Modi",   
     OptionC: "Arvind Kejriwal",   
     OptionD: "Ram Nath Kovind",
     Answer: "B"  
    },
    {
     Quiz: "Who is President Of Ukraine?",
     OptionA: "Rahul Gandhi",   
     OptionB: "Narendra Modi",   
     OptionC: "Arvind Kejriwal",   
     OptionD: "Ram Nath Kovind",
     Answer: "B"  
    },
    {
     Quiz: "In Which Country Amazon Forest ?",
     OptionA: "Rahul Gandhi",   
     OptionB: "Narendra Modi",   
     OptionC: "Arvind Kejriwal",   
     OptionD: "Ram Nath Kovind",
     Answer: "B"  
    },
    {
     Quiz: "Who is Home Misiter Of India?",
     OptionA: "Rahul Gandhi",   
     OptionB: "Narendra Modi",   
     OptionC: "Arvind Kejriwal",   
     OptionD: "Ram Nath Kovind",
     Answer: "B"  
    },
]


